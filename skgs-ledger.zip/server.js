const fs = require('fs').promises;
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const mongoose = require('mongoose');
const { Ledger, SEED } = require('./models/Ledger');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI;
const DATA_DIR = path.join(__dirname, 'data');
const LOCAL_LEDGER_FILE = path.join(DATA_DIR, 'ledger.json');
let useMongo = false;

const ensureLocalLedger = async () => {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    const raw = await fs.readFile(LOCAL_LEDGER_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    if (err.code === 'ENOENT') {
      await fs.writeFile(LOCAL_LEDGER_FILE, JSON.stringify(SEED, null, 2), 'utf8');
      return SEED;
    }
    throw err;
  }
};

const saveLocalLedger = async ({ ownCompany, companies }) => {
  const doc = { key: 'main', ownCompany, companies };
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(LOCAL_LEDGER_FILE, JSON.stringify(doc, null, 2), 'utf8');
  return doc;
};

const getLedger = async () => {
  if (useMongo) {
    let doc = await Ledger.findOne({ key: 'main' });
    if (!doc) {
      doc = await Ledger.create(SEED);
    }
    return doc;
  }
  return ensureLocalLedger();
};

const upsertLedger = async ({ ownCompany, companies }) => {
  if (useMongo) {
    return Ledger.findOneAndUpdate(
      { key: 'main' },
      { $set: { ownCompany, companies } },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );
  }
  return saveLocalLedger({ ownCompany, companies });
};

const startServer = () => {
  app.listen(PORT, () => {
    console.log(`🚀 SKGS Ledger server running at http://localhost:${PORT}`);
  });
};

const isValidMongoUri = (uri) => /^mongodb(\+srv)?:\/\//.test(uri);

const initialize = async () => {
  app.use(express.json({ limit: '2mb' }));
  app.use(express.static(path.join(__dirname, 'public')));

  if (MONGODB_URI) {
    if (!isValidMongoUri(MONGODB_URI)) {
      console.error('❌ Invalid MONGODB_URI. It should start with mongodb:// or mongodb+srv://');
    }

    try {
      await mongoose.connect(MONGODB_URI);
      useMongo = true;
      console.log('✅ Connected to MongoDB');
    } catch (err) {
      console.error('❌ MongoDB connection error:', err.message);
      console.warn('⚠️ Starting server with a local JSON fallback instead of MongoDB.');
      console.warn('   Fix your MONGODB_URI to use a valid Atlas or local MongoDB connection string.');
    }
  } else {
    console.warn('⚠️ MONGODB_URI is not set. Starting server with local JSON fallback storage.');
  }

  await ensureLocalLedger();
  startServer();
};

initialize();

// GET the whole ledger (all companies + their bills).
// Creates the document with starter seed data on first run.
app.get('/api/ledger', async (req, res) => {
  try {
    const doc = await getLedger();
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT (upsert) the whole ledger. The frontend sends the full
// { ownCompany, companies: [...] } object on every change.
app.put('/api/ledger', async (req, res) => {
  try {
    const { ownCompany, companies } = req.body;
    if (!Array.isArray(companies)) {
      return res.status(400).json({ error: 'companies must be an array' });
    }
    const doc = await upsertLedger({ ownCompany, companies });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Simple health check, handy for hosting platforms
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Fallback: send index.html for any other route (so the PWA
// works even if someone refreshes on a deep link)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
